exports.AUTH_ID = 'sKBzEwBPlpwnV1M9HWsWNDSRfPRkGOSz';
exports.AUTH_CLIENT = 'lameme.auth0.com';
