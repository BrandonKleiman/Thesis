export const SIGN_IN = 'SIGN_IN';
export const STORE_PROFILE = 'STORE_PROFILE';
export const LOADING ='LOADING';
export const HIDE_NAVBAR = 'HIDE_NAVBAR';
export const DONE_LOADING = 'DONE_LOADING';
